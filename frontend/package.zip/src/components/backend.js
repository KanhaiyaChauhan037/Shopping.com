// export const site = "https://adventurous-wasp-scrubs.cyclic.app"

export const site = "http://localhost:8080"