import React from 'react'

const MobileCheckout = () => {
  return (
    <div>
      Mobile
    </div>
  )
}

export default MobileCheckout
