import React from 'react'

const Fashion = () => {
  return (
    <div>
      
    </div>
  )
}

export default Fashion
